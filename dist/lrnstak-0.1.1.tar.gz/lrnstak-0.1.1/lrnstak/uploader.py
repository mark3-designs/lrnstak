
impor requests
import argparse
import joblib

def upload_model(model_name, version, file_path, base_url='http://localhost:5000/models/file'):
    try:
        # Load the model from the file
        model = joblib.load(file_path)

        # Prepare the endpoint URL
        endpoint_url = f'{base_url}/{model_name}'

        # Prepare the request payload
        files = {'model': open(file_path, 'rb')}
        data = {'version': version}

        # Send the POST request
        response = requests.post(endpoint_url, files=files, data=data)

        if response.status_code == 200:
            print('Model uploaded successfully.')
        else:
            print(f'Error uploading model. Status code: {response.status_code}, Message: {response.text}')

    except Exception as e:
        print(f'Error: {str(e)}')

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Upload a model to the model registry service.")
    parser.add_argument("model_name", type=str, help="Name of the model")
    parser.add_argument("version", type=int, help="Version of the model")
    parser.add_argument("file_path", type=str, help="File path to the model")

    args = parser.parse_args()

    upload_model(args.model_name, args.version, args.file_path)
